Please ensure that,

1.Specification Attribute is added for each Product in the Admin.
  (Admin -> Catalog -> Products -> 'Search Product' -> Edit ->Specification attributes -> Add attribute -> 'add values for Color attribute')
  (For Example : If there is Red colored Product,Add Red Value to Specification attribute)

Note :  If specification attribute didn't contain Red value, then there would be option to add Specification values
  (Admin -> Catalog -> Attribute -> Specification Attribute -> Default group -> Color edit -> Add Option (Color) -> Save
  
  (Specification attribute used for filtering products on the category details page. 
  So ensure that all Specification Attribute value for 'color attribute' is added for each color of product.
 
2.Product Attribute(color attribute) added for every color of Product
  (Admin -> Catalog -> Products -> 'Search Product' -> Edit -> Product attributes ->
   *If Color attribute not added =>  Add a new attribute -> Choose Attribute 'Color' -> Save ->then follow the step below
   *If there is Color Attribute  =>  Edit -> Add Values -> Save

 Note : Don't forget to select Picture for particular color and also the Attribute Value name should be same to Specification attribute name)

  
