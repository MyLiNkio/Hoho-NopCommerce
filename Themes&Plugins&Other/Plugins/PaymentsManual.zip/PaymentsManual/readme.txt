1. 'Nop.Plugin.Payments.Manual' directory contains source code.
2. 'Payments.Manual' contains binaries. Just drop it into \Plugins directory on your server.