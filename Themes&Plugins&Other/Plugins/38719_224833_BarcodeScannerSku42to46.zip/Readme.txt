1. 'WidgetsBarcodeScannerSku' contains binaries. Just drop it into \Plugins directory on your server.
