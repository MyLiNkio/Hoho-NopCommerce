﻿document.addEventListener('DOMContentLoaded', () => {
    function onScanSuccess(qrCodeMessage, decodedResult) {
        $.post('@Url.Action("GetProductUrlBySku", "WidgetsBarcodeScanner")', { sku: qrCodeMessage }, function (response) {
            if (response.success === true) {
                window.location.href = response.url;
            } else {
                $('#scanResult').text(response.message);
            }
        });
    }

    function onScanError(error) {
        console.error(error);
    }

    function isMobileDevice() {
        return (typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1);
    }

    const html5QrCode = new Html5Qrcode("reader");
    const config = { fps: 10, qrbox: { width: 350, height: 250 } };

    // Select back camera for mobile devices or webcam for non-mobile devices.
    const cameraIdOrConfig = isMobileDevice() ? { facingMode: "environment" } : { deviceId: "" };

    html5QrCode.start(cameraIdOrConfig, config, onScanSuccess, onScanError)
        .catch(err => {
            console.error("Unable to start scanning", err);
        });
});
