﻿IMPORTANT. We don't use SQL upgrade scripts anymore. Upgrade is performed automatically with migrations (during the first application start).

But in nopCommerce 4.60 the nopCommerce team created several upgrade scripts that you might consider running so please read more about this in the Readme.txt in the nopCommerce_UpgradeScripts folder.